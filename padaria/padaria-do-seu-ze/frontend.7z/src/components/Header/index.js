
import React from "react";
import "./index.css";

// Construindo um componente em formato de função
// É chamado de Statelles
const Header = () => (
    <div className="header">Meu Header</div>
);

export default Header;